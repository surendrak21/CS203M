import random
import math
import matplotlib.pyplot as plt

class Solution:

    def __init__(self):
        self.x = 0
        self.y = 0

    def randPoint(self):
        theta = random.uniform(0, 2 * math.pi)
        r = math.sqrt(random.uniform(0, 1))
        self.x = r * math.cos(theta)
        self.y = r * math.sin(theta)
        return [self.x, self.y]
    
    def simulate_bertrand_paradox(self, num_samples):
        favourable_outcomes = 0
        fig, ax = plt.subplots()
        circle = plt.Circle((0,0), 1, fill=False)
        ax.add_artist(circle)
        for _ in range(num_samples):
            x, y = self.randPoint()
            distance = math.sqrt(x**2 + y**2)
            if distance**2 <= 0.25:
                favourable_outcomes += 1
                ax.plot(x,y,'ro')
            else:
                ax.plot(x,y,'bo')
        prob = favourable_outcomes / num_samples
        ax.set_aspect('equal')
        plt.text(0, 1.2, f"Simulated probabilities: {prob}", ha='center')
        plt.show()
        return prob

solution = Solution()

probability = solution.simulate_bertrand_paradox(10000)

print(f"Simulated probabilities:",probability)
