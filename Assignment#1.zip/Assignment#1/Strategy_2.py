import pygame
import sys
import math
import random

# Initialize Pygame
pygame.init()

# Set up the display
WIDTH = 720
HEIGHT = 540
SCREEN_WIDTH_CM = 38.1
SCREEN_WIDTH_PIXELS = WIDTH
PIXELS_TO_CM = SCREEN_WIDTH_CM / SCREEN_WIDTH_PIXELS

# Set up the display
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Strategy-3 : Distance from the Centre")

# Set up colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
BLUE = (0, 0, 255)

# Set up circle parameters
circle_radius_cm = 10
circle_radius = int(circle_radius_cm / PIXELS_TO_CM)
circle_position = (WIDTH // 2, HEIGHT // 2)

# Function to generate random chord points
def generate_random_chord():
    z=random.uniform(circle_position[0],circle_position[0]+circle_radius)
    x1 = z
    y1 = circle_position[1] +math.sqrt(circle_radius**2-(x1-circle_position[0])**2)
    x2 = z
    y2 = circle_position[1] -math.sqrt(circle_radius**2-(x1-circle_position[0])**2)
    return ((x1, y1), (x2, y2))

# Function to calculate the length of a chord
def chord_length(chord):
    x1, y1 = chord[0]
    x2, y2 = chord[1]
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

# Main loop
clock = pygame.time.Clock()
chords = []
chord_timer = 0
chord_interval = 0.2  # Interval between chords (in seconds)
running = True
r=0
b=0
font = pygame.font.Font('freesansbold.ttf', 22)
 
# create a text surface object,
# on which text is drawn on it.
text = font.render("hh", True, WHITE)
 
# create a rectangular object for the
# text surface object
textRect = text.get_rect()
 
# set the center of the rectangular object.
textRect.center = (WIDTH // 2, 20)
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Generate random chords
    chord_timer += clock.get_time()/ 1000  # Convert milliseconds to seconds
    if chord_timer >= chord_interval:
        chord_timer -= chord_interval
        chord = generate_random_chord()
        chord_length_cm = chord_length(chord) * PIXELS_TO_CM
        chords.append(generate_random_chord())

    # Fill the window with black color
    window.fill(BLACK)

    # Draw the outer circle (white border)
    pygame.draw.circle(window, WHITE, circle_position, circle_radius, 2)

    # Draw the center of the circle (white color)
    pygame.draw.circle(window, WHITE, circle_position, 2)

    # Draw chords and calculating probability
    for chord in chords:
        # Draw chord
        if chord_length(chord) * PIXELS_TO_CM >= 10 * math.sqrt(3):
            pygame.draw.line(window, BLUE, chord[0], chord[1], 2)
            b=b+1
        else:
            pygame.draw.line(window, RED, chord[0], chord[1], 2)
            r=r+1
        text=font.render("probability= "+str(r/(r+b)),False,WHITE)
        window.blit(text, (100, 30))

    # Update the display
    pygame.display.update()

    # Cap the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()
sys.exit()