
# Assignment 1: Simulation of Bertrand's Paradox

Simualations of the three strategies (as discussed in class) that display the Bertrand's Paradox by estimating the probabilities obtained by each of the three sampling strategies.
## Strategy 1

This strategy calculates the probablity by fixing a point of the chord on one of the corners of the equilateral triangle and choosing the other end at random on the circumference of the circle. That probability comes out to be the angle between the sides of the triangle divided by the angle available for the chord which come out to be 60/180 = 1/3.


To run this simulation, pygame is required which can be installed by running the following in the terminal

```bash
  pip install pygame
```

## Result

![App Screenshot](https://via.placeholder.com/468x300?text=App+Screenshot+Here)

## Strategy 2

This strategy calculates the probability by choosing a chord at a certain distance from the center of the circle. That probability comes out to be the perpendicular distance of the side of the triangle from the center divided by the radius of the circle which comes out to be 1/2.


To run this simulation, pygame is required which can be installed by running the following in the terminal

```bash
  pip install pygame
```
## Result

![App Screenshot](https://via.placeholder.com/468x300?text=App+Screenshot+Here)

## Strategy 3

This strategy calculates the probability by choosing the midpoint of the chord at random inside the circle. That probability comes out to be the area of the incircle of the triangle divided by the area of the circle which comes out to be 1/4


To run this simulation, pygame is required which can be installed by running the following in the terminal

```bash
  pip install matplotlib
```
## Result

![App Screenshot](https://via.placeholder.com/468x300?text=App+Screenshot+Here)

## Group 17

- Lakshyta Mahajan - 220581
- Surendra Kumar Ahirwar - 211083
- Medikonda Amruth Raj - 220642
- Sarthak Paswan - 220976
- Taneshq Gorrakkh Zendey - 221123



